# AOG_Autosteer_ESP32
AgOpenGPS V5 and V4.3 autosteer code for ESP32

Code for ESP32. Pins could be set to your needs.
Default pins are for Gorms pinout/PCB https://github.com/GormR/HW_for_AgOpenGPS

Have fun
